The sunrise and sunset data is derived from


http://aa.usno.navy.mil/data/docs/RS_OneYear.html

The first line names the city and the second line encodes
its latitude and longitude, e.g.,

   Cleveland
   W08140N4129

This means that the longitude of Cleveland is 81 degrees 40 minutes 
west and its latitude is 41 degrees and 29 minutes north.

The rise and set times are then specified day-by-day with the data
for each month housed in a pair of columns. In particular, columns
2k and 2k+1 have the rise and set times for month k (Jan=1, Feb = 2, 
Mar = 3, etc.) Column 1 specifies day-of-the-month, 1 through 31.
Blanks are used for nonexistent dates (e.g., April 31).